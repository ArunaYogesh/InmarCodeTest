﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment3.Models
{
    public class OfferService
    {
        private List<Product> Inventory;

        private void AddProductToInventory()
        {
            Product product = new Product("P1",1000,"P1 Desc");
            Inventory.Add(product);
            product = new Product("P2", 200, "P2 Desc");
            Inventory.Add(product);
            product = new Product("P3", 400, "P3 Desc");
            Inventory.Add(product);
            product = new Product("P4", 700, "P4 Desc");
            Inventory.Add(product);
            product = new Product("P5", 600, "P5 Desc");
            Inventory.Add(product);
        }

        public OfferService()
        {
            AddProductToInventory();
        }

        public List<Product> GetAllProducts()
        {
            List<Product> listProduct = new List<Product>();

            foreach (var list in Inventory)
            {
                listProduct.Add(list);
            }

            return listProduct;
        }

        public List<Product> GetAllProductsFilter()
        {
            List<Product> listProduct = new List<Product>();

            //listProduct = Inventory.ToList(

            return listProduct;
        }

        public List<Product> GetTodaysOffers()
        {
            List<Product> listProduct = new List<Product>();

            return listProduct;
        }

        public void AddProduct(Product product)
        {
            Inventory.Add(product);
        }
    }
}