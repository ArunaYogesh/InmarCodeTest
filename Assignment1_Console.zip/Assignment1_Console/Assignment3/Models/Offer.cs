﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment3.Models
{
    public class Offer
    {
        string Offername;
        List<Product> Products;

        public Offer(string offername, List<Product> products)
        {
            Offername = offername;
            Products = products;
        }
    }
}