﻿using Assignment3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Assignment3.Controllers
{
    public class ProductController : ApiController
    {
        OfferService os = new OfferService();

        [HttpGet]
        [ActionName ("GetAllProducts")]
        public List<Product> GetAllProducts()
        {
            return os.GetAllProducts();
        }

        [HttpGet]
        [ActionName("GetAllProducts")]
        public List<Product> GetAllProducts_Filter()
        {
            return os.GetAllProducts();
        }

        [HttpGet]
        public List<Product> GetRandomProducts()
        {
            return os.GetTodaysOffers();
        }

        [HttpPost]
        public void AddProduct(Product product)
        {
            os.AddProduct(product);
        }
    }
}
