﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {

            string strInput = ""; // "abcdef";
            Console.Write("Read Inpu Value: ");
            strInput = Console.ReadLine();
            int strlength = strInput.Length;
            StringBuilder sbAppend = new StringBuilder();
            for (int i = strlength; i > 0; i--)
            {
                sbAppend = sbAppend.Append(strInput[i-1]);

            }

            Console.WriteLine("Reverese of Input string:" + sbAppend);
        }
    }
}
